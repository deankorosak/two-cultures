code and data for Two Cultures paper 
